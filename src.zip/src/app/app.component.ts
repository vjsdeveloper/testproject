import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'My Angular First';
  path = 'https://www.google.co.in/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png'

  size_C =100 //INPUT

  col_val = 3 //table

  buttontype1 = true; //button
  buttontype2 = false; //button

  color1 = "#d6d6d6"; //button
  color2 = "gray";//button

  useremail = "test@test.com"
  usermobile = "9999999999"

  forIf1 = true;
  forIf2 = false;
	listUsers = {
		name :'Abhishek Kadam',
		mailId :'abhishek@gmail.com',
		rating : 3.5464,
		mobileNo : 9999999999,
		price : 85.60,
		releaseDate: new Date(2018 , 7 ,21)
	}

  showDiv(){
  	console.log("div Clicked");
  }
  showBtnData(ev){
  	ev.stopPropagation();//this will prevent bubbling
  	console.log(ev);
  	console.log("button Clicked");
  }

  callMethod(){
  	console.log("The keyup Enter triggered");
  }

  showEmail(data){
  	console.log(data + "  Show Email ID");
  }
}
